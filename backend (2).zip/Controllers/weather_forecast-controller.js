const weatherForecastModel = require('../Models/weather_forecast');
const expressAsyncHandler = require('express-async-handler');
const { validateSchema } = require('../Validation/weather_forecast')

let addData = expressAsyncHandler(async (req,res) =>{

    const {error,value} = validateSchema(req.body);

    if(error){
        console.log(error);
        return res.status(400).send(error.details)
    }

    let addData = req.body;
    let{date,temperature_celsius,humidity_percentage,wind_speed_kmph,precipitation_mm,sunshine_hours,
        cloud_cover_percentage,dew_point_celsius,max_temperature_celsius,min_temperature_celsius} = addData;


    const data = new weatherForecastModel({
        date:date,
        temperature_celsius:temperature_celsius,
        humidity_percentage:humidity_percentage,
        wind_speed_kmph:wind_speed_kmph,
        precipitation_mm:precipitation_mm,
        sunshine_hours:sunshine_hours,
        cloud_cover_percentage:cloud_cover_percentage,
        dew_point_celsius:dew_point_celsius,
        max_temperature_celsius:max_temperature_celsius,
        min_temperature_celsius:min_temperature_celsius
    })

    await data.save()
    res.send(data);

})


    
module.exports = {addData};