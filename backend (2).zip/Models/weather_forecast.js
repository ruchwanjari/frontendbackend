const mongoose = require('mongoose');

const Schema = mongoose.Schema({
    date: {type:String, required:true},
    temperature_celsius:{type:Number, required:true},
    humidity_percentage:{type:Number, required:true},
    wind_speed_kmph:{type:Number},
    precipitation_mm:{type:Number, required:true},
    sunshine_hours:{type:Number, required:true},
    cloud_cover_percentage:{type:Number},
    dew_point_celsius : {type:Number} ,
    max_temperature_celsius:{type:Number, required:true},
    min_temperature_celsius:{type:Number}
});

module.exports = mongoose.model('data', Schema);