const joi = require('joi');

const validator = (schema) =>(payload)=>schema.validate(payload,{abortEarly:false});


const validateSchema = joi.object({
    date: joi.string().required(),
    humidity_percentage: joi.number().required(),
    wind_speed_kmph: joi.number().required(),
    precipitation_mm: joi.number().required(),
    temperature_celsius: joi.number().required(),
    sunshine_hours: joi.number().required(),
    cloud_cover_percentage: joi.number().required(),
    dew_point_celsius: joi.number().required(),
    max_temperature_celsius: joi.number().required(),
    min_temperature_celsius: joi.number().required()
});


exports.validateSchema = validator(validateSchema);