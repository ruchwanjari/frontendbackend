const express = require('express')
const router = express.Router();
const weather_forecastController=require('../Controllers/weather_forecast-controller');


router.post("/addData",weather_forecastController.addData)


module.exports=router;




