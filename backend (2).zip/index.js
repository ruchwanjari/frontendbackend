const express = require("express");
const app = express();
const cors = require('cors')
require('dotenv').config()
const dbConnection = require('./Helpers/mongo_db_connection');


var corsOptions = {
  origin: process.env.FRONTEND_URL,
  optionsSuccessStatus: 200 
}

app.use(cors(corsOptions))

const port = process.env.API_PORT;
const bodyParser = require("body-parser");
dbConnection();

const weather_forecast_router = require("./Routers/weather_forecast-router")

app.use(bodyParser.urlencoded({ extended: false }));

app.use(bodyParser.json());


app.use("/api", weather_forecast_router);

app.listen(port, () => {
  console.log(`Example app listening on port ${port}`);
});


